<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru_RU">
<context>
    <name>CntrlrComparison</name>
    <message>
        <location filename="../core/cntrlr_compare.cpp" line="12"/>
        <source>&lt;p&gt;&lt;b&gt;First data file:&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Первый файл со значениями:&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../core/cntrlr_compare.cpp" line="13"/>
        <location filename="../core/cntrlr_compare.cpp" line="33"/>
        <source>&lt;p&gt;&lt;b&gt;File path:&lt;/b&gt; %1&lt;br&gt;&lt;br&gt;&lt;b&gt;Processors:&lt;/b&gt; %2&lt;br&gt;&lt;br&gt;&lt;b&gt;Test type:&lt;/b&gt; %3&lt;br&gt;&lt;br&gt;&lt;b&gt;Data type:&lt;/b&gt; %4&lt;br&gt;&lt;br&gt;&lt;b&gt;Begin message length:&lt;/b&gt; %5&lt;br&gt;&lt;br&gt;&lt;b&gt;End message length:&lt;/b&gt; %6&lt;br&gt;&lt;br&gt;&lt;b&gt;Step length:&lt;/b&gt; %7&lt;br&gt;&lt;br&gt;&lt;b&gt;Noise message length:&lt;/b&gt; %8&lt;br&gt;&lt;br&gt;&lt;b&gt;Number of noise messages:&lt;/b&gt; %9&lt;br&gt;&lt;br&gt;&lt;b&gt;Number of noise processes:&lt;/b&gt; %10&lt;br&gt;&lt;br&gt;&lt;b&gt;Number of repeates:&lt;/b&gt; %11&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Путь к файлу:&lt;/b&gt; %1&lt;br&gt;&lt;br&gt;&lt;b&gt;Процессоров:&lt;/b&gt; %2&lt;br&gt;&lt;br&gt;&lt;b&gt;Тип теста:&lt;/b&gt; %3&lt;br&gt;&lt;br&gt;&lt;b&gt;Тип данных:&lt;/b&gt; %4&lt;br&gt;&lt;br&gt;&lt;b&gt;Начальная длина сообщений:&lt;/b&gt; %5&lt;br&gt;&lt;br&gt;&lt;b&gt;Конечная длина сообщений:&lt;/b&gt; %6&lt;br&gt;&lt;br&gt;&lt;b&gt;Шаг длины:&lt;/b&gt; %7&lt;br&gt;&lt;br&gt;&lt;b&gt;Длина шумовых сообщений:&lt;/b&gt; %8&lt;br&gt;&lt;br&gt;&lt;b&gt;Число шумовых сообщений:&lt;/b&gt; %9&lt;br&gt;&lt;br&gt;&lt;b&gt;Число &quot;шумящих&quot; процессов:&lt;/b&gt; %10&lt;br&gt;&lt;br&gt;&lt;b&gt;Количество повторов:&lt;/b&gt; %11&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../core/cntrlr_compare.cpp" line="32"/>
        <source>&lt;p&gt;&lt;b&gt;Second data file:&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Второй файл со значениями:&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>CntrlrDeviation</name>
    <message>
        <location filename="../core/cntrlr_deviat.cpp" line="12"/>
        <source>&lt;p&gt;&lt;b&gt;Data file:&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Файл со значениями:&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../core/cntrlr_deviat.cpp" line="13"/>
        <location filename="../core/cntrlr_deviat.cpp" line="33"/>
        <source>&lt;p&gt;&lt;b&gt;File path:&lt;/b&gt; %1&lt;br&gt;&lt;br&gt;&lt;b&gt;Processors:&lt;/b&gt; %2&lt;br&gt;&lt;br&gt;&lt;b&gt;Test type:&lt;/b&gt; %3&lt;br&gt;&lt;br&gt;&lt;b&gt;Data type:&lt;/b&gt; %4&lt;br&gt;&lt;br&gt;&lt;b&gt;Begin message length:&lt;/b&gt; %5&lt;br&gt;&lt;br&gt;&lt;b&gt;End message length:&lt;/b&gt; %6&lt;br&gt;&lt;br&gt;&lt;b&gt;Step length:&lt;/b&gt; %7&lt;br&gt;&lt;br&gt;&lt;b&gt;Noise message length:&lt;/b&gt; %8&lt;br&gt;&lt;br&gt;&lt;b&gt;Number of noise messages:&lt;/b&gt; %9&lt;br&gt;&lt;br&gt;&lt;b&gt;Number of noise processes:&lt;/b&gt; %10&lt;br&gt;&lt;br&gt;&lt;b&gt;Number of repeates:&lt;/b&gt; %11&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Путь к файлу:&lt;/b&gt; %1&lt;br&gt;&lt;br&gt;&lt;b&gt;Процессоров:&lt;/b&gt; %2&lt;br&gt;&lt;br&gt;&lt;b&gt;Тип теста:&lt;/b&gt; %3&lt;br&gt;&lt;br&gt;&lt;b&gt;Тип данных:&lt;/b&gt; %4&lt;br&gt;&lt;br&gt;&lt;b&gt;Начальная длина сообщений:&lt;/b&gt; %5&lt;br&gt;&lt;br&gt;&lt;b&gt;Конечная длина сообщений:&lt;/b&gt; %6&lt;br&gt;&lt;br&gt;&lt;b&gt;Шаг длины:&lt;/b&gt; %7&lt;br&gt;&lt;br&gt;&lt;b&gt;Длина шумовых сообщений:&lt;/b&gt; %8&lt;br&gt;&lt;br&gt;&lt;b&gt;Число шумовых сообщений:&lt;/b&gt; %9&lt;br&gt;&lt;br&gt;&lt;b&gt;Число &quot;шумящих&quot; процессов:&lt;/b&gt; %10&lt;br&gt;&lt;br&gt;&lt;b&gt;Количество повторов:&lt;/b&gt; %11&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../core/cntrlr_deviat.cpp" line="32"/>
        <source>&lt;p&gt;&lt;b&gt;File with deviations:&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Файл с отклонениями:&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>CntrlrSingle</name>
    <message>
        <location filename="../core/cntrlr_single.cpp" line="6"/>
        <source>&lt;p&gt;&lt;b&gt;File path:&lt;/b&gt; %1&lt;br&gt;&lt;br&gt;&lt;b&gt;Processors:&lt;/b&gt; %2&lt;br&gt;&lt;br&gt;&lt;b&gt;Test type:&lt;/b&gt; %3&lt;br&gt;&lt;br&gt;&lt;b&gt;Data type:&lt;/b&gt; %4&lt;br&gt;&lt;br&gt;&lt;b&gt;Begin message length:&lt;/b&gt; %5&lt;br&gt;&lt;br&gt;&lt;b&gt;End message length:&lt;/b&gt; %6&lt;br&gt;&lt;br&gt;&lt;b&gt;Step length:&lt;/b&gt; %7&lt;br&gt;&lt;br&gt;&lt;b&gt;Noise message length:&lt;/b&gt; %8&lt;br&gt;&lt;br&gt;&lt;b&gt;Number of noise messages:&lt;/b&gt; %9&lt;br&gt;&lt;br&gt;&lt;b&gt;Number of noise processes:&lt;/b&gt; %10&lt;br&gt;&lt;br&gt;&lt;b&gt;Number of repeates:&lt;/b&gt; %11&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Путь к файлу:&lt;/b&gt; %1&lt;br&gt;&lt;br&gt;&lt;b&gt;Процессоров:&lt;/b&gt; %2&lt;br&gt;&lt;br&gt;&lt;b&gt;Тип теста:&lt;/b&gt; %3&lt;br&gt;&lt;br&gt;&lt;b&gt;Тип данных:&lt;/b&gt; %4&lt;br&gt;&lt;br&gt;&lt;b&gt;Начальная длина сообщений:&lt;/b&gt; %5&lt;br&gt;&lt;br&gt;&lt;b&gt;Конечная длина сообщений:&lt;/b&gt; %6&lt;br&gt;&lt;br&gt;&lt;b&gt;Шаг длины:&lt;/b&gt; %7&lt;br&gt;&lt;br&gt;&lt;b&gt;Длина шумовых сообщений:&lt;/b&gt; %8&lt;br&gt;&lt;br&gt;&lt;b&gt;Число шумовых сообщений:&lt;/b&gt; %9&lt;br&gt;&lt;br&gt;&lt;b&gt;Число &quot;шумящих&quot; процессов:&lt;/b&gt; %10&lt;br&gt;&lt;br&gt;&lt;b&gt;Количество повторов:&lt;/b&gt; %11&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>FullViewer</name>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="79"/>
        <location filename="../GUI/fullviewer.cpp" line="730"/>
        <location filename="../GUI/fullviewer.cpp" line="1084"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="217"/>
        <source>Comparison of 2 files</source>
        <translation>Сравнение 2 файлов</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="218"/>
        <source>&lt;p align=left&gt;If a value in the first file is greater than or&lt;br&gt;equal to corresponding value in the second&lt;br&gt;file, the color is &lt;span style=&quot;color:green&quot;&gt;green&lt;/span&gt;, otherwise is &lt;span style=&quot;color:red&quot;&gt;red&lt;/span&gt;&lt;/p&gt;</source>
        <translation>&lt;p align=left&gt;Если значение из первого файла не меньше,&lt;br&gt;чем соответствующее значение из второго,&lt;br&gt;цвет &lt;span style=&quot;color:green&quot;&gt;зелёный&lt;/span&gt;, иначе - &lt;span style=&quot;color:red&quot;&gt;красный&lt;/span&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="124"/>
        <source>Hosts</source>
        <translation>Хосты</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="140"/>
        <source>&lt;p align=&quot;center&quot;&gt;Reading data file(s)...&lt;/p&gt;</source>
        <translation>&lt;p align=&quot;center&quot;&gt;Чтение файл(ов) с данными...&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="204"/>
        <location filename="../GUI/fullviewer.cpp" line="209"/>
        <source> file &quot;</source>
        <translation> файл &quot;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="205"/>
        <location filename="../GUI/fullviewer.cpp" line="210"/>
        <source>&quot; is loaded</source>
        <translation>&quot; загружен</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="226"/>
        <source>&lt;p align=&quot;center&quot;&gt;Initializing render system...&lt;/p&gt;</source>
        <translation>&lt;p align=&quot;center&quot;&gt;Инициализация системы визуализации...&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="230"/>
        <source>&lt;p align=&quot;center&quot;&gt;Initializing output image...&lt;/p&gt;</source>
        <translation>&lt;p align=&quot;center&quot;&gt;Инициализация выходного изображения...&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="251"/>
        <source>Render!</source>
        <translation>Отобразить!</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="334"/>
        <source>&lt;p align=&quot;center&quot;&gt;Generating render options...&lt;/p&gt;</source>
        <translation>&lt;p align=&quot;center&quot;&gt;Создание настроек графики...&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="123"/>
        <source>General</source>
        <translation>Общие</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="126"/>
        <source>Device</source>
        <translation>Аппаратура</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="79"/>
        <source>&lt;p align=&quot;center&quot;&gt;Cannot create OpenCL-based renderer.&lt;br&gt;Try OpenMP-based one?&lt;/p&gt;</source>
        <translation>&lt;p align=&quot;center&quot;&gt;Невозможно создать визуализатор на OpenCL.&lt;br&gt;Попробовать визуализатор на OpenMP?&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="127"/>
        <source>Render options</source>
        <translation>Настройки графики</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="197"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="197"/>
        <source>&lt;p align=center&gt;This test was not finished.&lt;br&gt;Expected %1 instead of %2&lt;br&gt;as end message length value.&lt;/p&gt;</source>
        <translation>&lt;p align=center&gt;Этот тест не был завершён.&lt;br&gt;Конечная длина сообщений&lt;br&gt;должна была быть %1, а не %2.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="261"/>
        <source>&lt;p align=&quot;center&quot;&gt;Filling information widgets...&lt;/p&gt;</source>
        <translation>&lt;p align=&quot;center&quot;&gt;Заполнение информационных виджетов...&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="305"/>
        <source>&lt;span style=&quot;color:green&quot;&gt;Number of processors:&lt;/span&gt; %1&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Test type:&lt;/span&gt; %2&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Data type:&lt;/span&gt; %3&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Initial message length:&lt;/span&gt; %4&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Final message length:&lt;/span&gt; %5&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Step of length:&lt;/span&gt; %6&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Noise message length:&lt;/span&gt; %7&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Number of noise messages:&lt;/span&gt; %8&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Number of noise processors:&lt;/span&gt; %9&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Number of repeats:&lt;/span&gt; %10</source>
        <translation>&lt;span style=&quot;color:green&quot;&gt;Процессоров:&lt;/span&gt; %1&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Тип теста:&lt;/span&gt; %2&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Тип данных:&lt;/span&gt; %3&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Начальная длина сообщений:&lt;/span&gt; %4&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Конечная длина сообщений:&lt;/span&gt; %5&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Шаг длины сообщений:&lt;/span&gt; %6&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Длина шумовых сообщений:&lt;/span&gt; %7&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Шумовых сообщений:&lt;/span&gt; %8&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;&quot;Шумных&quot; процессов:&lt;/span&gt; %9&lt;br&gt;&lt;br&gt;&lt;span style=&quot;color:green&quot;&gt;Повторов:&lt;/span&gt; %10</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="325"/>
        <source>Controls...</source>
        <translation>Управление...</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="331"/>
        <source>&lt;span style=&quot;color:green&quot;&gt;Computing units:&lt;/span&gt; %1</source>
        <translation>&lt;span style=&quot;color:green&quot;&gt;Выч. устройств:&lt;/span&gt; %1</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="372"/>
        <source>&lt;p align=&quot;center&quot;&gt;Building 3D model...&lt;/p&gt;</source>
        <translation>&lt;p align=&quot;center&quot;&gt;Построение 3D модели...&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="581"/>
        <source>&lt;p align=&quot;center&quot; style=&quot;color:rgb(100,100,100)&quot;&gt;Rebuilding 3D model...&lt;/p&gt;</source>
        <translation>&lt;p align=&quot;center&quot; style=&quot;color:rgb(100,100,100)&quot;&gt;Восстановление 3D модели...&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="970"/>
        <source>&lt;p&gt;&lt;span style=&quot;color:red&quot;&gt;Process-sender:&lt;/span&gt; &lt;span style=&quot;color:white&quot;&gt;r&lt;/span&gt;%1&lt;br&gt;&lt;span style=&quot;color:blue&quot;&gt;Process-receiver:&lt;/span&gt; %2&lt;br&gt;&lt;span style=&quot;color:yellow&quot;&gt;Message length:&lt;/span&gt; &lt;span style=&quot;color:white&quot;&gt;r&lt;/span&gt;%3&lt;/p&gt;&lt;p&gt;</source>
        <translation>&lt;p&gt;&lt;span style=&quot;color:red&quot;&gt;Процесс-отправитель:&lt;/span&gt; %1&lt;br&gt;&lt;span style=&quot;color:blue&quot;&gt;Процесс-получатель:&lt;/span&gt; &lt;span style=&quot;color:white&quot;&gt;ь&lt;/span&gt;%2&lt;br&gt;&lt;span style=&quot;color:yellow&quot;&gt;Длина сообщения:&lt;/span&gt; &lt;span style=&quot;color:white&quot;&gt;ььь&lt;/span&gt;%3&lt;/p&gt;&lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="981"/>
        <source>&lt;b&gt;Value:&lt;/b&gt; %1&lt;br&gt;&lt;span style=&quot;color:lightgray&quot;&gt;&lt;i&gt;Second value:&lt;/i&gt;&lt;/span&gt;&lt;/p&gt;</source>
        <translation>&lt;b&gt;Значение:&lt;/b&gt; %1&lt;br&gt;&lt;span style=&quot;color:lightgray&quot;&gt;&lt;i&gt;Второе значение:&lt;/i&gt;&lt;/span&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="984"/>
        <source>&lt;b&gt;Value:&lt;/b&gt; %1&lt;br&gt;&lt;b&gt;Deviation:&lt;/b&gt; %2&lt;/p&gt;</source>
        <translation>&lt;b&gt;Значение:&lt;/b&gt; %1&lt;br&gt;&lt;b&gt;Отклонение:&lt;/b&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="987"/>
        <source>&lt;b&gt;&quot;Left&quot; value:&lt;/b&gt; %1&lt;br&gt;&lt;b&gt;&quot;Right&quot; value:&lt;/b&gt; %2&lt;/p&gt;</source>
        <translation>&lt;b&gt;&quot;Левое&quot; значение:&lt;/b&gt; %1&lt;br&gt;&lt;b&gt;&quot;Правое&quot; значение:&lt;/b&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="1023"/>
        <location filename="../GUI/fullviewer.cpp" line="1030"/>
        <source> | %1 s | </source>
        <translation> | %1 с | </translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.cpp" line="730"/>
        <location filename="../GUI/fullviewer.cpp" line="1084"/>
        <source>&lt;p align=center&gt;An error occured in OpenCL-based renderer.&lt;br&gt;Try OpenMP-based one?&lt;/p&gt;</source>
        <translation>&lt;p align=center&gt;Возникла ошибка в визуализаторе на OpenCL.&lt;br&gt;Попробовать визуализатор на OpenMP?&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.h" line="199"/>
        <source>Snd</source>
        <translation>Отп</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.h" line="205"/>
        <source>Rcv</source>
        <translation>Плч</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.h" line="211"/>
        <source>ML</source>
        <translation>ДС</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.h" line="351"/>
        <source>&quot;Point selection&quot;</source>
        <translation>&quot;Выделение точки&quot;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.h" line="351"/>
        <source>Leave &quot;point selection&quot; mode?</source>
        <translation>Выйти из режима &quot;выделения точки&quot;?</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.h" line="482"/>
        <source>Controls</source>
        <translation>Управление</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.h" line="483"/>
        <source>&lt;div&gt;&lt;span style=&quot;color:darkred&quot;&gt;&apos;W&apos;, &apos;A&apos;, &apos;S&apos;, &apos;D&apos;&lt;/span&gt; - move &quot;camera&quot; up/left/down/right&lt;/div&gt;&lt;div&gt;&lt;span style=&quot;color:darkred&quot;&gt;&apos;Z&apos;, &apos;X&apos;&lt;/span&gt; - move &quot;camera&quot; to/from obserever&lt;/div&gt;&lt;div&gt;&lt;span style=&quot;color:darkred&quot;&gt;&apos;+&apos;, &apos;-&apos;, &apos;Scroll&apos;&lt;/span&gt; - zoom in/out&lt;/div&gt;&lt;div&gt;&lt;span style=&quot;color:darkred&quot;&gt;Press left mouse key and move mouse&lt;/span&gt; - rotation&lt;/div&gt;&lt;div&gt;&lt;span style=&quot;color:darkred&quot;&gt;&apos;Esc&apos;&lt;/span&gt; - close this tab&lt;/div&gt;</source>
        <translation>&lt;div&gt;&lt;span style=&quot;color:darkred&quot;&gt;&apos;W&apos;, &apos;A&apos;, &apos;S&apos;, &apos;D&apos;&lt;/span&gt; - переместить &quot;камеру&quot; вверх / влево / вниз / вправо&lt;/div&gt;&lt;div&gt;&lt;span style=&quot;color:darkred&quot;&gt;&apos;Z&apos;, &apos;X&apos;&lt;/span&gt; - переместить &quot;камеру&quot; к / от наблюдателю(я)&lt;/div&gt;&lt;div&gt;&lt;span style=&quot;color:darkred&quot;&gt;&apos;+&apos;, &apos;-&apos;, &apos;Scroll&apos;&lt;/span&gt; - увеличить / уменьшить&lt;/div&gt;&lt;div&gt;&lt;span style=&quot;color:darkred&quot;&gt;Двигать мышью при зажатой ЛКМ&lt;/span&gt; - вращать&lt;/div&gt;&lt;div&gt;&lt;span style=&quot;color:darkred&quot;&gt;&apos;Esc&apos;&lt;/span&gt; - закрыть эту вкладку&lt;/div&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.h" line="493"/>
        <source>Hosts: description</source>
        <translation>Хосты: описание</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.h" line="493"/>
        <source>&lt;b&gt;1.&lt;/b&gt; Double clicking on a &lt;i&gt;&lt;b&gt;number&lt;/b&gt;&lt;/i&gt; N selects&lt;br&gt;all &quot;points&quot; with their &lt;i&gt;sender&lt;/i&gt; or &lt;i&gt;receiver&lt;/i&gt;&lt;br&gt;coordinates equal to (N-1).&lt;br&gt;&lt;b&gt;2.&lt;/b&gt; Double clicking on &lt;i&gt;&lt;b&gt;host&apos; name&lt;/b&gt;&lt;/i&gt; selects all&lt;br&gt;&lt;i&gt;&lt;b&gt;numbers&lt;/b&gt;&lt;/i&gt; corresponding to equal names</source>
        <translation>&lt;b&gt;1.&lt;/b&gt; Двойной клик на &lt;i&gt;&lt;b&gt;номере&lt;/b&gt;&lt;/i&gt; N выделяет&lt;br&gt;все &quot;точки&quot; с координатами &lt;i&gt;отправителя&lt;/i&gt;&lt;br&gt;или &lt;i&gt;получателя&lt;/i&gt;, равными (N-1).&lt;br&gt;&lt;b&gt;2.&lt;/b&gt; Двойной клик на &lt;i&gt;&lt;b&gt;имени хоста&lt;/b&gt;&lt;/i&gt; выбирает&lt;br&gt;все &lt;i&gt;&lt;b&gt;номера&lt;/b&gt;&lt;/i&gt;, соответствующие хостам с&lt;br&gt;таким же именем</translation>
    </message>
</context>
<context>
    <name>HostsBrowser</name>
    <message>
        <location filename="../GUI/fullviewer.h" line="674"/>
        <location filename="../GUI/fullviewer.h" line="716"/>
        <source>Hosts: error</source>
        <translation>Хосты: ошибка</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.h" line="675"/>
        <source>Invalid number: &apos;</source>
        <translation>Неверный номер: &apos;</translation>
    </message>
    <message>
        <location filename="../GUI/fullviewer.h" line="717"/>
        <source>More than one line is selected.&lt;br&gt;Cannot proceed</source>
        <translation>Выделено больше одной строки.&lt;br&gt;Невозможно продолжить</translation>
    </message>
</context>
<context>
    <name>ICntrlr</name>
    <message>
        <location filename="../core/cntrlr_abstract.h" line="37"/>
        <source>Hosts&apos; names are unavailable</source>
        <translation>Названия хостов недоступны</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="77"/>
        <source>&lt;p&gt;Network Viewer Qt v2 is a part of PARUS project.&lt;br&gt;Link: &lt;a href=&quot;http://parus.sf.net/&quot;&gt;http://parus.sf.net/&lt;/a&gt;&lt;br&gt;&lt;br&gt;&lt;u&gt;&lt;b&gt;Authors:&lt;/b&gt;&lt;/u&gt;&lt;br&gt;&lt;br&gt;&lt;i&gt;Salnikov A.N.&lt;/i&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;salnikov@cmc.msu.ru&lt;br&gt;&lt;i&gt;Andreev D.Y.&lt;/i&gt;&lt;br&gt;&lt;i&gt;Lebedev R.D.&lt;/i&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; rmn.lebedev@gmail.com&lt;br&gt;&lt;i&gt;Bannikov P.S.&lt;/i&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;pashokkk@bk.ru&lt;br&gt;&lt;br&gt;Copyright &amp;copy; 2013&amp;nbsp; &amp;nbsp; Pavel S. Bannikov&lt;/p&gt;</source>
        <translation>&lt;p&gt;Network Viewer Qt v2 является частью проекта PARUS.&lt;br&gt;Ссылка: &lt;a href=&quot;http://parus.sf.net/&quot;&gt;http://parus.sf.net/&lt;/a&gt;&lt;br&gt;&lt;br&gt;&lt;u&gt;&lt;b&gt;Авторы:&lt;/b&gt;&lt;/u&gt;&lt;br&gt;&lt;br&gt;&lt;i&gt;Сальников А.Н.&lt;/i&gt;&amp;nbsp; &amp;nbsp; salnikov@cmc.msu.ru&lt;br&gt;&lt;i&gt;Андреев Д.Ю.&lt;/i&gt;&lt;br&gt;&lt;i&gt;Лебедев Р.Д.&lt;/i&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&amp;nbsp;rmn.lebedev@gmail.com&lt;br&gt;&lt;i&gt;Банников П.С.&lt;/i&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;pashokkk@bk.ru&lt;br&gt;&lt;br&gt;Copyright &amp;copy; 2013&amp;nbsp; &amp;nbsp; Банников П.С&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="107"/>
        <source>E:</source>
        <translation>О:</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="108"/>
        <source>S:</source>
        <translation>У:</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="109"/>
        <source>I:</source>
        <translation>И:</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="125"/>
        <source>Open data file</source>
        <translation>Открыть файл с данными</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="209"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="210"/>
        <source>Failed to automatically find file with hosts&apos; names for the file&lt;br&gt;&lt;b&gt;&apos;%1 &apos;&lt;/b&gt;&lt;br&gt;(&lt;i&gt;Assumed&lt;/i&gt; &lt;b&gt;&apos;%2 &apos;&lt;/b&gt;).&lt;br&gt;&lt;br&gt;Do you want to locate it manually?</source>
        <translation>Не удалось автоматически обнаружить файл с именами хостов для файла&lt;br&gt;&lt;b&gt;&apos;%1 &apos;&lt;/b&gt;&lt;br&gt;(&lt;i&gt;Предполагалось&lt;/i&gt; &lt;b&gt;&apos;%2 &apos;&lt;/b&gt;).&lt;br&gt;&lt;br&gt;Хотите указать путь вручную?</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="215"/>
        <source>Open file with hosts</source>
        <translation>Открыть файл с именами хостов</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="258"/>
        <location filename="../GUI/mainwindow.cpp" line="296"/>
        <source>file &quot;</source>
        <translation>файл &quot;</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="150"/>
        <source>Open file with deviations</source>
        <translation>Открыть файл со значениями отклонений</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="124"/>
        <source>Open first data file</source>
        <translation>Открыть первый файл с данными</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="54"/>
        <source>Welcome to Network Viewer Qt v2!</source>
        <translation>Добро пожаловать в Network Viewer Qt v2!</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="76"/>
        <source>About PARUS Network Viewer Qt v2</source>
        <translation>О PARUS Network Viewer Qt v2</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="156"/>
        <source>Open second data file</source>
        <translation>Открыть второй файл с данными</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.cpp" line="259"/>
        <location filename="../GUI/mainwindow.cpp" line="297"/>
        <source>&quot; is loaded</source>
        <translation>&quot; загружен</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="63"/>
        <source>Load</source>
        <translation>Загрузить</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="164"/>
        <source>File type</source>
        <translation>Тип файла</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="186"/>
        <source>Working mode</source>
        <translation>Режим работы</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="211"/>
        <source>View</source>
        <translation>Просмотр</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="243"/>
        <source>Text</source>
        <translation>Текстовый</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="269"/>
        <source>Single</source>
        <translation>Один файл</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="282"/>
        <source>With deviations</source>
        <translation>С отклонениями</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="289"/>
        <source>Compare 2 files</source>
        <translation>Сравнение 2 файлов</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="328"/>
        <source>Topology</source>
        <translation>Топология</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="398"/>
        <source>Start</source>
        <translation>Старт</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="450"/>
        <source>Tools</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="454"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="495"/>
        <source>Show logs</source>
        <translation>Отображать лог</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="498"/>
        <source>Show/hide logs</source>
        <translation>Показать/скрыть лог</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="501"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="513"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="517"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../GUI/mainwindow.ui" line="548"/>
        <source>Log</source>
        <translation>Лог</translation>
    </message>
</context>
<context>
    <name>MatrixViewer</name>
    <message>
        <location filename="../GUI/matrixviewer.cpp" line="141"/>
        <source>Matrix for message length %1</source>
        <translation>Матрица для сообщения длины %1</translation>
    </message>
    <message>
        <location filename="../GUI/matrixviewer.cpp" line="143"/>
        <source>Matrix for window messages from %1 to %2</source>
        <translation>Матрица для сообщений с длинами от %1 до %2</translation>
    </message>
    <message>
        <location filename="../GUI/matrixviewer.cpp" line="145"/>
        <source>

Rectangle: (%1; %2) - (%3; %4)</source>
        <translation>

Координаты диагонали: (%1; %2) - (%3; %4)</translation>
    </message>
    <message>
        <location filename="../GUI/matrixviewer.cpp" line="287"/>
        <location filename="../GUI/matrixviewer.cpp" line="289"/>
        <source>: zoomed</source>
        <translation>: увеличено</translation>
    </message>
</context>
<context>
    <name>PairViewer</name>
    <message>
        <location filename="../GUI/pairviewer.h" line="64"/>
        <source>message&lt;br&gt;lengths</source>
        <translation>длины&lt;br&gt;сообщений</translation>
    </message>
    <message>
        <location filename="../GUI/pairviewer.h" line="66"/>
        <location filename="../GUI/pairviewer.h" line="78"/>
        <source>values</source>
        <translation>значения</translation>
    </message>
    <message>
        <location filename="../GUI/pairviewer.h" line="79"/>
        <source>deviations</source>
        <translation>отклонения</translation>
    </message>
    <message>
        <location filename="../GUI/pairviewer.h" line="85"/>
        <source>values&lt;br&gt;in file 1</source>
        <translation>значения&lt;br&gt;в файле 1</translation>
    </message>
    <message>
        <location filename="../GUI/pairviewer.h" line="88"/>
        <source>values&lt;br&gt;in file 2</source>
        <translation>значения&lt;br&gt;в файле 2</translation>
    </message>
    <message>
        <location filename="../GUI/pairviewer.h" line="104"/>
        <source>difference&lt;br&gt;between&lt;br&gt;(1) and (2)</source>
        <translation>разность&lt;br&gt;между&lt;br&gt;(1) и (2)</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../core/renderer_OpenCL.cpp" line="17"/>
        <source>cannot pass the argument %1 to the kernel</source>
        <translation>невозможно передать ядру %1-й аргумент</translation>
    </message>
    <message>
        <location filename="../core/renderer_OpenCL.cpp" line="45"/>
        <source>no suitable device was found</source>
        <translation>не найдено подходящее устройство</translation>
    </message>
    <message>
        <location filename="../core/renderer_OpenCL.cpp" line="54"/>
        <source>cannot create the context</source>
        <translation>невозможно создать контекст</translation>
    </message>
    <message>
        <location filename="../core/renderer_OpenCL.cpp" line="61"/>
        <source>source file &quot;</source>
        <translation>файл с исходным кодом &quot;</translation>
    </message>
    <message>
        <location filename="../core/renderer_OpenCL.cpp" line="61"/>
        <source>&quot; cannot be read</source>
        <translation>прочитать не удалось</translation>
    </message>
    <message>
        <location filename="../core/renderer_OpenCL.cpp" line="100"/>
        <source>cannot create the program</source>
        <translation>невозможно создать OpenCL-программу</translation>
    </message>
    <message>
        <location filename="../core/renderer_OpenCL.cpp" line="112"/>
        <source>cannot build the program
</source>
        <translation>невозможно скомпилировать OpenCL-программу
</translation>
    </message>
    <message>
        <location filename="../core/renderer_OpenCL.cpp" line="133"/>
        <location filename="../core/renderer_OpenCL.cpp" line="232"/>
        <location filename="../core/renderer_OpenCL.cpp" line="242"/>
        <location filename="../core/renderer_OpenCL.cpp" line="252"/>
        <location filename="../core/renderer_OpenCL.cpp" line="297"/>
        <location filename="../core/renderer_OpenCL.cpp" line="307"/>
        <location filename="../core/renderer_OpenCL.cpp" line="317"/>
        <source>no such kernel named &quot;</source>
        <translation>не существует ядра с именем &quot;</translation>
    </message>
    <message>
        <location filename="../core/renderer_OpenCL.cpp" line="142"/>
        <source>cannot create the command queue</source>
        <translation>невозможно создать очередь команд</translation>
    </message>
    <message>
        <location filename="../core/renderer_OpenCL.cpp" line="191"/>
        <source>cannot allocate memory for the image on GPU</source>
        <translation>невозможно выделить память под изображение на GPU</translation>
    </message>
    <message>
        <location filename="../core/renderer_OpenCL.cpp" line="259"/>
        <source>unknown representation type of &quot;points&quot;</source>
        <translation>неизвестный режим отображения &quot;точек&quot;</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="35"/>
        <source>file &apos;%1&apos; has incorrect format:</source>
        <translation>файл &apos;%1&apos; имеет недопустимый формат:</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="39"/>
        <source>not enough memory</source>
        <translation>не хватает памяти</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="40"/>
        <source>file &apos;%1&apos; does not exist or cannot be opened</source>
        <translation>файл &apos;%1&apos; не существует, либо его нельзя открыть</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="41"/>
        <source>file &apos;%1&apos; is not a valid NetCDF file</source>
        <translation>файл &apos;%1&apos; не является корректным NetCDF файлом</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="42"/>
        <source>unexpected end of file &apos;%1&apos;</source>
        <translation>неожиданный конец файла &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="43"/>
        <source>cannot read number of processors</source>
        <translation>невозможно считать число процессоров</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="44"/>
        <source>cannot read begin message length</source>
        <translation>невозможно считать начальную длину сообщений</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="45"/>
        <source>cannot read end message length</source>
        <translation>невозможно считать конечную длину сообщений</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="46"/>
        <source>cannot read step length</source>
        <translation>невозможно считать шаг длины сообщений</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="47"/>
        <source>cannot read noise message length</source>
        <translation>невозможно считать длину шумовых сообщений</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="48"/>
        <source>cannot read number of noise messages</source>
        <translation>невозможно считать число шумовых сообщений</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="49"/>
        <source>cannot read number of noise processors</source>
        <translation>невозможно считать число &quot;шумных&quot; процессов</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="50"/>
        <source>cannot read number of repeats</source>
        <translation>невозможно считать количество повторов</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="51"/>
        <source>no 3D data was found</source>
        <translation>не найдены 3D-данные</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="52"/>
        <source>2D submatrices are not square in the file &apos;%1&apos;</source>
        <translation>двумерные подматрицы не являются квадратными в файле &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="53"/>
        <source>file &apos;%1&apos; with hosts&apos; names does not exist or cannot be opened</source>
        <translation>файл &apos;%1&apos;, содерждащий имена хостов, не существует, либо его нельзя открыть</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="54"/>
        <source>data file and file with deviations are incompatible</source>
        <translation>не совпадают главные параметры у файла с данными и файла с отклонениями</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="55"/>
        <source>two data files are incompatible</source>
        <translation>у двух файлов с данными не совпадают параметры</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="56"/>
        <source>data read beyond the end of the file</source>
        <translation>попытка чтения данных за концом файла</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="57"/>
        <source>error while reading NetCDF file</source>
        <translation>ошибка чтения NetCDF файла</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="58"/>
        <source>the same file was selected twice</source>
        <translation>один и тот же файл был выбран дважды</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="59"/>
        <source>the viewer was not created</source>
        <translation>не удалось создать окно для просмотра</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="60"/>
        <source>unknown working mode</source>
        <translation>неизвестный режим работы</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="62"/>
        <source>cannot create the renderer: %1</source>
        <translation>невозможно создать визуализатор: %1</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="63"/>
        <source>error in the renderer: %1</source>
        <translation>ошибка в визуализаторе: %1</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="64"/>
        <source>hosts&apos; names are undefined. Cannot proceed</source>
        <translation>названия хостов не были заданы. Невозможно продожить операцию</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="65"/>
        <source>file &apos;%1&apos; does not contain a matching topology</source>
        <translation>топология из файла &apos;%1&apos; относится к другой архитектуре</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="66"/>
        <source>file &apos;%1&apos; contains duplicate names</source>
        <translation>в файле &apos;%1&apos; найдены повторяющиеся имена</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="67"/>
        <source>the topology from file &apos;%1&apos; and the retrieved topology match but it is useless</source>
        <translation>топология из файла &apos;%1&apos; и выявленная топология относятся к одной архитектуре, но это не принесёт пользу</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="69"/>
        <source>missed &apos;graph&apos;</source>
        <translation>пропущено &apos;graph&apos;</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="70"/>
        <source>&apos;{&apos; symbol is not the last visible symbol in the line</source>
        <translation>символ &apos;{&apos; не является последним видимым символом в строке</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="71"/>
        <source>a vertex ID must consist of letter &apos;v&apos; followed by a number</source>
        <translation>ID вершины должен состоять из буквы &apos;v&apos; и числа</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="72"/>
        <source>overflow in a vertex index</source>
        <translation>переполнение при считывании индекса вершины</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="73"/>
        <source>missed &apos;[&apos;</source>
        <translation>пропущено &apos;[&apos;</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="74"/>
        <source>missed &apos;]&apos;</source>
        <translation>пропущено &apos;]&apos;</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="75"/>
        <source>missed &apos;label=&apos;</source>
        <translation>пропущено &apos;label=&apos;</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="76"/>
        <source>missed forward quote</source>
        <translation>пропущена открывающая кавычка</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="77"/>
        <source>missed backward quote</source>
        <translation>пропущена закрывающая кавычка</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="78"/>
        <source>missed &apos;;&apos;</source>
        <translation>пропущено &apos;;&apos;</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="79"/>
        <source>&apos;;&apos; symbol is not at the end of the line</source>
        <translation>символ &apos;;&apos; не является последним символом в строке</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="80"/>
        <source>overflow in an end of an edge</source>
        <translation>переполнение при считывании конца ребра</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="81"/>
        <source>incorrect vertex at one end of an edge was found</source>
        <translation>один из концов ребра не является допустимой вершиной</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="82"/>
        <source>missed &apos;--&apos;</source>
        <translation>пропущено &apos;--&apos;</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="83"/>
        <source>self-loop was found</source>
        <translation>найдена петля</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="84"/>
        <source>zero or negative bandwidth was found</source>
        <translation>обнаружена неположительная пропускная способность</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="85"/>
        <source>missed &apos;Gbit/s&apos;</source>
        <translation>пропущено &apos;Gbit/s&apos;</translation>
    </message>
    <message>
        <location filename="../GUI/err_msgs.h" line="86"/>
        <source>duplicate edge was found</source>
        <translation>найден повтор ребра</translation>
    </message>
</context>
<context>
    <name>RenderOpts</name>
    <message>
        <location filename="../GUI/render_opts.cpp" line="122"/>
        <source>cubes</source>
        <translation>кубики</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="127"/>
        <source>spheres, type 1</source>
        <translation>сферы, тип 1</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="132"/>
        <location filename="../GUI/render_opts.cpp" line="141"/>
        <location filename="../GUI/render_opts.cpp" line="155"/>
        <location filename="../GUI/render_opts.cpp" line="166"/>
        <location filename="../GUI/render_opts.cpp" line="212"/>
        <source>?</source>
        <translation>?</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="136"/>
        <source>spheres, type 2</source>
        <translation>сферы, тип 2</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="177"/>
        <location filename="../GUI/render_opts.cpp" line="232"/>
        <location filename="../GUI/render_opts.cpp" line="282"/>
        <source>min:</source>
        <translation>мин:</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="193"/>
        <location filename="../GUI/render_opts.cpp" line="251"/>
        <location filename="../GUI/render_opts.cpp" line="301"/>
        <source>max:</source>
        <translation>макс:</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="61"/>
        <source>Volume building</source>
        <translation>Построение объёмов</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="207"/>
        <source>enable mode</source>
        <translation>активировать</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="261"/>
        <source>Values-1:</source>
        <translation>Значения-1:</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="264"/>
        <source>Values-2:</source>
        <translation>Значения-2:</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="314"/>
        <source>Values:</source>
        <translation>Значения:</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="27"/>
        <source>Shape of &quot;points&quot;</source>
        <translation>Форма &quot;точек&quot;</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="38"/>
        <source>&quot;Depth constraint&quot;</source>
        <translation>&quot;Ограничение глубины&quot;</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.cpp" line="46"/>
        <source>Color stretching</source>
        <translation>Растяжение цветов</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.h" line="74"/>
        <source>About &quot;spheres, type 1&quot; representation</source>
        <translation>Об отображении &quot;сферами типа 1&quot;</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.h" line="75"/>
        <source>&quot;Points&quot; are represented as spheres&lt;br&gt;with constant intensities</source>
        <translation>&quot;Точки&quot; отображаются в виде сфер&lt;br&gt;с постоянной интенсивностью</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.h" line="80"/>
        <source>About &quot;spheres, type 2&quot; representation</source>
        <translation>Об отображении &quot;сферами типа 2&quot;</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.h" line="81"/>
        <source>&quot;Points&quot; are represented as spheres&lt;br&gt;with their intensities descending&lt;br&gt;from centres to borders (~ 1/r&lt;sup&gt;2&lt;/sup&gt;)</source>
        <translation>&quot;Точки&quot; рисуются в виде сфер,&lt;br&gt;интенсивность которых спадает&lt;br&gt;от центров к краям (~ 1/r&lt;sup&gt;2&lt;/sup&gt;)</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.h" line="89"/>
        <source>About &quot;depth constraint&quot;</source>
        <translation>Об &quot;ограничении глубины&quot;</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.h" line="90"/>
        <source>&quot;Depth constraint&quot; means maximum&lt;br&gt;number of &quot;points&quot; which can intersect&lt;br&gt;with one virtual ray</source>
        <translation>&quot;Ограничением глубины&quot;&lt;br&gt;называется наибольшее&lt;br&gt;число &quot;точек&quot;, с которыми&lt;br&gt;может пересечься один&lt;br&gt;виртуальный луч</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.h" line="95"/>
        <source>About color stretching</source>
        <translation>О растяжении цветов</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.h" line="96"/>
        <source>Normally minimum of all values in a file turns&lt;br&gt;to color 0 and maximum - to color 255, and linear&lt;br&gt;interpolation is performed on other values. By&lt;br&gt;moving sliders below one can adjust minimum and&lt;br&gt;maximum so all values less than this new minimum&lt;br&gt;value will turn to color 0 and all values greater&lt;br&gt;than this maximum value will turn to color 255&lt;br&gt;(linear interpolation algorithm is left unchanged).</source>
        <translation>Обычно минимум всех значений файла&lt;br&gt;превращается в цвет с интенсивностью 0, а&lt;br&gt;максимум - в цвет с интенсивностью 255; остальные&lt;br&gt;значения получаются линейной интерполяцией.&lt;br&gt;Перемещая ползунки, расположенные ниже,&lt;br&gt;можно изменять минимум и максимум.&lt;br&gt;Тогда все значения, меньшие либо&lt;br&gt;равные новому минимуму, превратятся в цвет&lt;br&gt;с интенсивностью 0, значения, больше либо равные&lt;br&gt;новому максимуму, - в цвет с интенсивностью 255 (линейная интерполяция не изменится).</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.h" line="110"/>
        <source>About volume building</source>
        <translation>О построении объёмов</translation>
    </message>
    <message>
        <location filename="../GUI/render_opts.h" line="111"/>
        <source>Only &quot;points&quot; with values between specified&lt;br&gt;minimum and maximum will be visible&lt;br&gt;&lt;br&gt;&lt;b&gt;&apos;Depth constraint&apos; will take&lt;br&gt;no effect in this mode!&lt;/b&gt;</source>
        <translation>Будут видны только те &quot;точки&quot;, значения в которых&lt;br&gt; лежат между заданными минимумом и максимумом&lt;br&gt;&lt;br&gt;&lt;b&gt;&apos;Ограничение глубины&apos; не действует&lt;br&gt;в этом режиме!&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>TabViewer</name>
    <message>
        <location filename="../GUI/tabviewer.cpp" line="99"/>
        <source>only part of the window with lengths from %1 to %2 was loaded</source>
        <translation>загружена только часть окна с длинами сообщений от %1 до %2</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.cpp" line="102"/>
        <location filename="../GUI/tabviewer.cpp" line="110"/>
        <source>loaded</source>
        <translation>загружено</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.cpp" line="102"/>
        <source>partly </source>
        <translation>частично </translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.cpp" line="107"/>
        <source>window with lengths from %1 to %2 was loaded</source>
        <translation>окно с длинами сообщений от %1 до %2 загружено</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.cpp" line="126"/>
        <source>: window was dropped</source>
        <translation>: окно удалено</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.cpp" line="131"/>
        <source>not loaded</source>
        <translation>не загружено</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.cpp" line="132"/>
        <location filename="../GUI/tabviewer.cpp" line="133"/>
        <source>N/A</source>
        <translation>Н/Д</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.cpp" line="143"/>
        <source>Matrix for message length %1</source>
        <translation>Матрица для сообщения длины %1</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.cpp" line="174"/>
        <source>Row %1, message lengths from %2 to %3</source>
        <translation>Ряд %1, длины сообщений от %2 до %3</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.cpp" line="205"/>
        <source>Column %1, message lengths from %2 to %3</source>
        <translation>Столбец %1, длины сообщений от %2 до %3</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.cpp" line="233"/>
        <source>Point (%1,%2): message lengths from %3 to %4</source>
        <translation>Точка (%1,%2): длины сообщений от %3 до %4</translation>
    </message>
</context>
<context>
    <name>TopoOptions</name>
    <message>
        <location filename="../GUI/topoviewer.ui" line="20"/>
        <source>Topology viewer options</source>
        <translation>Настройки просмотра топологии</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="37"/>
        <source>Retrieving</source>
        <translation>Выявление</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="49"/>
        <source>Dispersion of distances between processors in shared memory:</source>
        <translation>Разброс в расстояниях между процессорами на общей памяти:</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="93"/>
        <source>Merge two simpex channels into one duplex channel if a dispersion of values is not greater than:</source>
        <translation>Преобразовывать два симплексных канала в один дуплексный, если разброс значений не превышает:</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="143"/>
        <source>Building</source>
        <translation>Построение</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="155"/>
        <source>Maximize distances between
unconnected vertices</source>
        <translation>Максимизировать расстояния между
несвязанными вершинами</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="187"/>
        <source>- minimize impact on the other parts of the graph:</source>
        <translation>- минимизировать влияние на остальные части графа:</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="215"/>
        <source>set manually:</source>
        <translation>задать вручную:</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="240"/>
        <source>auto detect (may be slow!)</source>
        <translation>автоопределение (может работать медленно!)</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="297"/>
        <source>number of tries:</source>
        <translation>число попыток:</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="360"/>
        <source>Consider non-existent edges with existence probability less than</source>
        <translation>Считать несуществующими рёбра, у которых вероятность существования меньше, чем</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="451"/>
        <source>defined by message length:</source>
        <translation>определяются по длине сообщений:</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="473"/>
        <source>simple average of all values</source>
        <translation>среднее арифметическое всех значений</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="495"/>
        <source>median of all values</source>
        <translation>медиана всех значений</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="518"/>
        <source> Values for edges&apos; lengths:</source>
        <translation>Значения для длин рёбер:</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="527"/>
        <source>Drawing</source>
        <translation>Отрисовка</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="545"/>
        <source>Hide edges with existence
probability less than</source>
        <translation>Не рисовать рёбра, у
которыx вероятность
существования меньше, чем</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="587"/>
        <source>immediate
redraw</source>
        <translation>отрисовка
изменений</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.ui" line="607"/>
        <source>Show host names near the vertices</source>
        <translation>Отображать имена хостов рядом с вершинами</translation>
    </message>
</context>
<context>
    <name>TopoViewerOpts</name>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="25"/>
        <source>Maximization of distances</source>
        <translation>Максимизация расстояний</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="26"/>
        <source>This feature prevents two unconnected vertices
from having the same coordinates. But maximizing
distances between unconnected vertices may affect
lengths of other edges thus decreasing the accuracy.
User is given a coefficient which provides a tradeoff
between preserving lengths of edges and physical
correctness.</source>
        <translation>Данная опция предотвращает ситуации, когда две
несвязанные вершины имеют одинаковые координаты.
Однако максимизация расстояний между несвязанными
вершинами может отрицательно повлиять на длины рёбер,
снижая таким образом точность построения.
Пользователю предоставляется коэффициент, с помощью
которого можно балансировать между сохранением длин
рёбер и физической корректностью.</translation>
    </message>
</context>
<context>
    <name>TopologyViewer</name>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="200"/>
        <location filename="../GUI/topoviewer.cpp" line="413"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="200"/>
        <location filename="../GUI/topoviewer.cpp" line="413"/>
        <source>&lt;p align=center&gt;This test was not finished.&lt;br&gt;Expected %1 instead of %2&lt;br&gt;as end message length value.&lt;/p&gt;</source>
        <translation>&lt;p align=center&gt;Этот тест не был завершён.&lt;br&gt;Конечная длина сообщений&lt;br&gt;должна была быть %1, а не %2.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="715"/>
        <location filename="../GUI/topoviewer.cpp" line="729"/>
        <location filename="../GUI/topoviewer.cpp" line="2650"/>
        <location filename="../GUI/topoviewer.cpp" line="2664"/>
        <source>Graph building</source>
        <translation>Построение графа</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="716"/>
        <location filename="../GUI/topoviewer.cpp" line="2651"/>
        <source> was not precise:</source>
        <translation> не было точным:</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="719"/>
        <location filename="../GUI/topoviewer.cpp" line="725"/>
        <location filename="../GUI/topoviewer.cpp" line="2654"/>
        <location filename="../GUI/topoviewer.cpp" line="2660"/>
        <source>of edges have %1% length error or greater</source>
        <translation>рёбер имеет не менее %1% ошибки в длине</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="727"/>
        <location filename="../GUI/topoviewer.cpp" line="2662"/>
        <source>(the graph has &lt;b&gt;%1&lt;/b&gt; edges in all)&lt;br&gt;</source>
        <translation>(в графе всего &lt;b&gt;%1&lt;/b&gt; рёбер)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="1741"/>
        <source>Open file with &quot;ideal&quot; topology</source>
        <translation>Открыть файл с эталонной топологией</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="2217"/>
        <source>Comparison of topologies</source>
        <translation>Сравнение топологий</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="2218"/>
        <source>The topology from file&lt;br&gt;&lt;i&gt;%1&lt;/i&gt;&lt;br&gt;is similar to the retrieved topology by &lt;b&gt;%2%&lt;/b&gt;</source>
        <translation>Топология из файла&lt;br&gt;&lt;i&gt;%1&lt;/i&gt;&lt;br&gt;похожа на выявленную топологию на &lt;b&gt;%2%&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="2644"/>
        <source>&quot;ideal&quot; topology for &apos;</source>
        <translation>эталонная топология для &apos;</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="478"/>
        <source> file &quot;</source>
        <translation> файл &quot;</translation>
    </message>
    <message>
        <location filename="../GUI/topoviewer.cpp" line="479"/>
        <source>&quot; is loaded</source>
        <translation>&quot; загружен</translation>
    </message>
</context>
<context>
    <name>ui_MatrixViewer</name>
    <message>
        <location filename="../GUI/matrixviewer.ui" line="52"/>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <location filename="../GUI/matrixviewer.ui" line="73"/>
        <source>Zoom</source>
        <translation>Масштаб
ировать</translation>
    </message>
    <message>
        <location filename="../GUI/matrixviewer.ui" line="89"/>
        <source>From (current):</source>
        <translation>От (текущее):</translation>
    </message>
    <message>
        <location filename="../GUI/matrixviewer.ui" line="96"/>
        <source>To:</source>
        <translation>До:</translation>
    </message>
    <message>
        <location filename="../GUI/matrixviewer.ui" line="106"/>
        <source>Normalize</source>
        <translation>Нормализовать по</translation>
    </message>
    <message>
        <location filename="../GUI/matrixviewer.ui" line="112"/>
        <source>Local</source>
        <translation>текущей матрице</translation>
    </message>
    <message>
        <location filename="../GUI/matrixviewer.ui" line="122"/>
        <source>Current window</source>
        <translation>всему окну</translation>
    </message>
    <message>
        <location filename="../GUI/matrixviewer.ui" line="181"/>
        <source>info</source>
        <translation>информация</translation>
    </message>
</context>
<context>
    <name>ui_TabViewer</name>
    <message>
        <location filename="../GUI/tabviewer.ui" line="14"/>
        <source>MainWindow</source>
        <translation>MainWindow</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="144"/>
        <source>i</source>
        <translation>i</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="207"/>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="230"/>
        <source>To Do</source>
        <translation>Действия</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="236"/>
        <source>State</source>
        <translation>Состояние</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="242"/>
        <source>Window:</source>
        <translation>Окно:</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="249"/>
        <source>From:</source>
        <translation>От:</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="256"/>
        <location filename="../GUI/tabviewer.ui" line="270"/>
        <source>N/A</source>
        <translation>Н/Д</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="263"/>
        <source>To:</source>
        <translation>До:</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="277"/>
        <source>not loaded</source>
        <translation>не загружено</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="305"/>
        <source>Load window</source>
        <translation>Загрузить окно</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="315"/>
        <source>From</source>
        <translation>От</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="322"/>
        <source>To</source>
        <translation>До</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="393"/>
        <source>Load</source>
        <translation>Загрузить</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="400"/>
        <source>Drop</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="410"/>
        <source>Show</source>
        <translation>Отобразить</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="416"/>
        <source>Matrix</source>
        <translation>Матрица для данной длины</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="426"/>
        <source>(for window)</source>
        <translation>(для окна)</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="435"/>
        <source>update from current matrix</source>
        <translation>считывать указанную точку
текущей матрицы</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="452"/>
        <source>Row</source>
        <translation>Ряд</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="469"/>
        <source>Column</source>
        <translation>Столбец</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="479"/>
        <source>Pair</source>
        <translation>Точка по координатам</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="506"/>
        <source>Data</source>
        <translation>Сведения</translation>
    </message>
    <message>
        <location filename="../GUI/tabviewer.ui" line="519"/>
        <source>Hosts</source>
        <translation>Хосты</translation>
    </message>
</context>
</TS>
