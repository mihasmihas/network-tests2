#ifndef __PARUS_CONFIG_H__
#define __PARUS_CONFIG_H__
#define  PARUS_VERSION "2.0.1"
#define  PARUS_INSTALL_DIR "/home/mihas/network_tests-2.0.1"
#define  PARUS_DATA_DIR "/home/mihas/network_tests-2.0.1/var/spool/network_tests2"
#endif /* __PARUS_CONFIG_H__ */
