#!/bin/sh
aclocal
autoconf -o configure configure.ac
